#include "hello.h"
int main(int argc, char* argv[])
{
  hello();

  return 0;
}
