This directory contains the spec file for the Stampede cluster at
TACC.
