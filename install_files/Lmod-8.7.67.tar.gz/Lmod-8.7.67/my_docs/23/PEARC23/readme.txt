Find *.pptx in ~/c/txt/presentations/PEARC23
