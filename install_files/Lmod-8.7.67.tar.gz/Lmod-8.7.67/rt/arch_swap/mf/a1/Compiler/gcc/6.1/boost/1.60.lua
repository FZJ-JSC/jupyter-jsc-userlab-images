setenv(myModuleName(),myModuleVersion())
