# -*- lua -*-
scDescriptT = {
  {
     ["dir"]       = pathJoin(os.getenv("outputDir"),"bcd/cacheDir"),
     ["timestamp"] = pathJoin(os.getenv("outputDir"),"bcd/timestamp"),
  },
}
