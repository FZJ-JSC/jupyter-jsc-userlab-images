prepend_path("PATH","/foo/bar/1.4-dbg/bin")
