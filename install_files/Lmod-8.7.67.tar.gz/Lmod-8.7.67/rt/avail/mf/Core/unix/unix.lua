-- -*- lua -*-
prepend_path('MANPATH',  '/usr/share/man')
prepend_path('INFOPATH', '/usr/share/info')
prepend_path('INFOPATH', '/local/info')
