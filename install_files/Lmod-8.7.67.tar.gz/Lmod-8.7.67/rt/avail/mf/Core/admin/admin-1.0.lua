-- -*- lua -*-
setenv("ADMIN_MODULE_LOADED","1")
prepend_path('PATH','/usr/sbin/://sbin///')
