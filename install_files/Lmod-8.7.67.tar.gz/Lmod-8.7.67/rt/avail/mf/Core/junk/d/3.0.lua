setenv("JUNK","RTM_3")
