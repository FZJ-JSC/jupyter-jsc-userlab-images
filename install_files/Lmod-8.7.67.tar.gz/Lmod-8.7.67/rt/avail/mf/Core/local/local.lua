-- -*- lua -*-
prepend_path('PATH','/usr/local/share/bin')
