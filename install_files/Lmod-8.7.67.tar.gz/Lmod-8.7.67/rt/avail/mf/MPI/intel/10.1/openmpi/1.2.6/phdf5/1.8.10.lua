setenv("TACC_PHDF5_DIR","/unknown/apps/phdf5")
