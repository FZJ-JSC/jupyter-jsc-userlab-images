setenv("VERSION",myModuleVersion())
