#!/bin/bash
# -*- shell-script -*-


. $LMOD_ROOT/lmod/init/bash

export MODULEPATH=$PWD/my_modules/Core

# Put whatever module commands you need to show your issue
# Modify the modules in my_modules/Core if necessary if you are using the software hierarchy
module load gcc mpich
module av





